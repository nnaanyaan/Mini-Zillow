package com.java1234.model;

/**
 * @propertyclass Administrator
 *
 */
public class House {

	private int id;
	private String address; 
	private String propertyclass; 
	private String propertyuse; 
	private int price; 
	private Integer schoolTypeId; 
	private Integer refuseTypeId; 
	// foreign key
	private String schoolTypeName; 
	private String refuseTypeName; 
	
	
	
	public House() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public House(String address, String propertyclass, String propertyuse, int price, Integer schoolTypeId, Integer refuseTypeId) {
		super();
		this.address = address;
		this.propertyclass = propertyclass;
		this.propertyuse = propertyuse;
		this.price = price;
		this.schoolTypeId = schoolTypeId;
		this.refuseTypeId = refuseTypeId;
	}

	


	public House(int id, String address, String propertyclass, String propertyuse, int price, Integer schoolTypeId, Integer refuseTypeId) {
		super();
		this.id = id;
		this.address = address;
		this.propertyclass = propertyclass;
		this.propertyuse = propertyuse;
		this.price = price;
		this.schoolTypeId = schoolTypeId;
		this.refuseTypeId = refuseTypeId;
	}



	public House(String address, String propertyclass, Integer schoolTypeId) {
		super();
		this.address = address;
		this.propertyclass = propertyclass;
		this.schoolTypeId = schoolTypeId;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getPropertyclass() {
		return propertyclass;
	}



	public void setPropertyclass(String propertyclass) {
		this.propertyclass = propertyclass;
	}



	public String getPropertyuse() {
		return propertyuse;
	}



	public void setPropertyuse(String propertyuse) {
		this.propertyuse = propertyuse;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public Integer getSchoolTypeId() {
		return schoolTypeId;
	}



	public void setSchoolTypeId(Integer schoolTypeId) {
		this.schoolTypeId = schoolTypeId;
	}



	public Integer getRefuseTypeId() {
		return refuseTypeId;
	}



	public void setRefuseTypeId(Integer refuseTypeId) {
		this.refuseTypeId = refuseTypeId;
	}



	public String getSchoolTypeName() {
		return schoolTypeName;
	}



	public void setSchoolTypeName(String schoolTypeName) {
		this.schoolTypeName = schoolTypeName;
	}



	public String getRefuseTypeName() {
		return refuseTypeName;
	}



	public void setRefuseTypeName(String refuseTypeName) {
		this.refuseTypeName = refuseTypeName;
	}

	
	
}
