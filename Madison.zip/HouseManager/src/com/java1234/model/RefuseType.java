package com.java1234.model;

public class RefuseType {

	private int id; 
	private String refuseTypeName; 
	private String refuseTypeDesc; 
	
	
	
	public RefuseType() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public RefuseType(String refuseTypeName, String refuseTypeDesc) {
		super();
		this.refuseTypeName = refuseTypeName;
		this.refuseTypeDesc = refuseTypeDesc;
	}
	
	


	public RefuseType(int id, String refuseTypeName, String refuseTypeDesc) {
		super();
		this.id = id;
		this.refuseTypeName = refuseTypeName;
		this.refuseTypeDesc = refuseTypeDesc;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRefuseTypeName() {
		return refuseTypeName;
	}
	public void setRefuseTypeName(String refuseTypeName) {
		this.refuseTypeName = refuseTypeName;
	}
	public String getRefuseTypeDesc() {
		return refuseTypeDesc;
	}
	public void setRefuseTypeDesc(String refuseTypeDesc) {
		this.refuseTypeDesc = refuseTypeDesc;
	}


	@Override
	public String toString() {
		return refuseTypeName;
	}

	
}
