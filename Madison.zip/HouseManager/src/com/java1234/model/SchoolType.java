package com.java1234.model;

public class SchoolType {

	private int id; 
	private String schoolTypeName; 
	private String schoolTypeDesc; 
	
	
	
	public SchoolType() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public SchoolType(String schoolTypeName, String schoolTypeDesc) {
		super();
		this.schoolTypeName = schoolTypeName;
		this.schoolTypeDesc = schoolTypeDesc;
	}
	
	


	public SchoolType(int id, String schoolTypeName, String schoolTypeDesc) {
		super();
		this.id = id;
		this.schoolTypeName = schoolTypeName;
		this.schoolTypeDesc = schoolTypeDesc;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSchoolTypeName() {
		return schoolTypeName;
	}
	public void setSchoolTypeName(String schoolTypeName) {
		this.schoolTypeName = schoolTypeName;
	}
	public String getSchoolTypeDesc() {
		return schoolTypeDesc;
	}
	public void setSchoolTypeDesc(String schoolTypeDesc) {
		this.schoolTypeDesc = schoolTypeDesc;
	}


	@Override
	public String toString() {
		return schoolTypeName;
	}

	
}
