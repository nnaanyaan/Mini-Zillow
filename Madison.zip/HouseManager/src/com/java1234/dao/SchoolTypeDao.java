package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.SchoolType;
import com.java1234.util.StringUtil;



public class SchoolTypeDao {

	/**
	 * @param con
	 * @param schoolType
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,SchoolType schoolType)throws Exception{
		String sql="insert into t_schoolType values(null,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, schoolType.getSchoolTypeName());
		pstmt.setString(2, schoolType.getSchoolTypeDesc());
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param schoolType
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,SchoolType schoolType)throws Exception{
		StringBuffer sb=new StringBuffer("select * from t_schoolType");
		if(StringUtil.isNotEmpty(schoolType.getSchoolTypeName())){
			sb.append(" and schoolTypeName like '%"+schoolType.getSchoolTypeName()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String id)throws Exception{
		String sql="delete from t_schoolType where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param schoolType
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,SchoolType schoolType)throws Exception{
		String sql="update t_schoolType set schoolTypeName=?,schoolTypeDesc=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, schoolType.getSchoolTypeName());
		pstmt.setString(2, schoolType.getSchoolTypeDesc());
		pstmt.setInt(3, schoolType.getId());
		return pstmt.executeUpdate();
	}
}
