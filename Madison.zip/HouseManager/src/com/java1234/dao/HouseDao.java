package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.House;
import com.java1234.util.StringUtil;


public class HouseDao {

	/**
	 * @param con
	 * @param house
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,House house)throws Exception{
		String sql="insert into t_house values(null,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, house.getAddress());
		pstmt.setString(2, house.getPropertyclass());
		pstmt.setString(3, house.getPropertyuse());
		pstmt.setInt(4, house.getPrice());
		pstmt.setInt(5, house.getSchoolTypeId());
		pstmt.setInt(6, house.getRefuseTypeId());
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param house
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,House house)throws Exception{
		StringBuffer sb=new StringBuffer("select * from t_house b,t_schooltype bt where b.schoolTypeId=bt.id");
		if(StringUtil.isNotEmpty(house.getAddress())){
			sb.append(" and b.address like '%"+house.getAddress()+"%'");
		}
		if(StringUtil.isNotEmpty(house.getPropertyclass())){
			sb.append(" and b.propertyclass like '%"+house.getPropertyclass()+"%'");
		}
		if(house.getSchoolTypeId()!=null && house.getSchoolTypeId()!=-1){
			sb.append(" and b.schoolTypeId="+house.getSchoolTypeId());
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString());
		return pstmt.executeQuery();
	}
	
	/**
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String id)throws Exception{
		String sql="delete from t_house where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param house
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,House house)throws Exception{
		String sql="update t_house set houseName=?,author=?,sex=?,price=?,houseDesc=?,houseTypeId=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, house.getAddress());
		pstmt.setString(2, house.getPropertyclass());
		pstmt.setString(3, house.getPropertyuse());
		pstmt.setInt(4, house.getPrice());
		pstmt.setInt(5, house.getSchoolTypeId());
		pstmt.setInt(6, house.getRefuseTypeId());
		pstmt.setInt(7, house.getId());
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param houseTypeId
	 * @return
	 * @throws Exception
	 */
	public boolean existHouseBySchoolTypeId(Connection con,String schoolTypeId)throws Exception{
		String sql="select * from t_house where houseTypeId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, schoolTypeId);
		ResultSet rs=pstmt.executeQuery();
		return rs.next();
	}
}
