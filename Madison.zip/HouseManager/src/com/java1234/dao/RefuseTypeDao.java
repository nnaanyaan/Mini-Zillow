package com.java1234.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.java1234.model.RefuseType;
import com.java1234.util.StringUtil;


/**
 * @author Administrator
 *
 */
public class RefuseTypeDao {

	/**
	 * @param con
	 * @param refuseType
	 * @return
	 * @throws Exception
	 */
	public int add(Connection con,RefuseType refuseType)throws Exception{
		String sql="insert into t_refuseType values(null,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, refuseType.getRefuseTypeName());
		pstmt.setString(2, refuseType.getRefuseTypeDesc());
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param refuseType
	 * @return
	 * @throws Exception
	 */
	public ResultSet list(Connection con,RefuseType refuseType)throws Exception{
		StringBuffer sb=new StringBuffer("select * from t_refuseType");
		if(StringUtil.isNotEmpty(refuseType.getRefuseTypeName())){
			sb.append(" and refuseTypeName like '%"+refuseType.getRefuseTypeName()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		return pstmt.executeQuery();
	}
	
	/**
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int delete(Connection con,String id)throws Exception{
		String sql="delete from t_refuseType where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, id);
		return pstmt.executeUpdate();
	}
	
	/**
	 * @param con
	 * @param refuseType
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,RefuseType refuseType)throws Exception{
		String sql="update t_refuseType set refuseTypeName=?,refuseTypeDesc=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, refuseType.getRefuseTypeName());
		pstmt.setString(2, refuseType.getRefuseTypeDesc());
		pstmt.setInt(3, refuseType.getId());
		return pstmt.executeUpdate();
	}
}
