package com.java1234.util;

import java.sql.Connection;
import java.sql.DriverManager;


/**
 * Database tool class
 * @author Administrator
 *
 */
public class DbUtil {

	private String dbUrl="jdbc:mysql://localhost:3306/madison"; // connect�
	private String dbUserName="root"; // User name
	private String dbPassword="123456"; // password
	private String jdbcName="com.mysql.jdbc.Driver"; // drive name.
	
	/**
	 * get the connection of database.
	 * @return
	 * @throws Exception
	 */
	public Connection getCon()throws Exception{
		Class.forName(jdbcName);
		Connection con=DriverManager.getConnection(dbUrl, dbUserName, dbPassword);
		return con;
	}
	
	/**
	 * close the connection of database.
	 * @param con
	 * @throws Exception
	 */
	public void closeCon(Connection con)throws Exception{
		if(con!=null){
			con.close();
		}
	}
	
	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
		try {
			dbUtil.getCon();
			System.out.println("Wow. Connect Successfully");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sorry, Failed");
		}
	}
	
}
