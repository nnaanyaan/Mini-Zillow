package com.java1234.util;
/**
 * string character tool class
 * @author lingou zhu
 */
public class StringUtil {
	/*
	 * decide if it is empty.
	 */
	public static boolean isEmpty(String str){
		if(str==null || "".equals(str.trim())){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * decide if it is not empty.
	 * @param str
	 * @return
	 */
	public static boolean isNotEmpty(String str){
		if(str!=null && !"".equals(str.trim())){
			return true;
		}else{
			return false;
		}
	}
}
