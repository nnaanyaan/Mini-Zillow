package com.java1234.view;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JInternalFrame;

import com.java1234.dao.HouseDao;
import com.java1234.dao.RefuseTypeDao;
import com.java1234.dao.SchoolTypeDao;
import com.java1234.model.RefuseType;
import com.java1234.model.SchoolType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SchoolTypeManageInterFrm extends JInternalFrame {
	
	private DbUtil dbUtil=new DbUtil();
	private SchoolTypeDao schoolTypeDao=new SchoolTypeDao();
	
	private HouseDao houseDao=new HouseDao();
	private JTable schoolTypeTable;
	private JTextField s_schoolTypeNameTxt;
	private JTextField idTxt;
	private JTextField schoolTypeNameTxt;
	private JTextArea schoolTypeDescTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchoolTypeManageInterFrm frame = new SchoolTypeManageInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchoolTypeManageInterFrm() {
		setMaximizable(true);
		setClosable(true);
		setResizable(true);
		setIconifiable(true);
		setTitle("School District Management");
		setBounds(100, 100, 775, 659);
		
		JScrollPane scrollPane = new JScrollPane();
//		scrollPane.addMouseListener(new MouseAdapter() {
//			@Override
//			public void mousePressed(MouseEvent e) {
//				schoolTypeTableMousePressed(e);
//			}
//		});
		
		JLabel lblNewLabel = new JLabel("School District Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		s_schoolTypeNameTxt = new JTextField();
		s_schoolTypeNameTxt.setColumns(10);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schoolTypeSearchActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(SchoolTypeManageInterFrm.class.getResource("/images/search.png")));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Modify and Delete", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(94, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 561, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel)
								.addGap(39)
								.addComponent(s_schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, 185, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnNewButton))
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 558, GroupLayout.PREFERRED_SIZE)))
					.addGap(104))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(35)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(s_schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addGap(55)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
					.addGap(45)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 234, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(38, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_1 = new JLabel("id:");
		
		idTxt = new JTextField();
		idTxt.setEditable(false);
		idTxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("School District Name:");
		
		schoolTypeNameTxt = new JTextField();
		schoolTypeNameTxt.setColumns(10);
		
		JLabel lblSchoolDistrictDesc = new JLabel("School District Desc:");
		
		schoolTypeDescTxt = new JTextArea();
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schoolTypeDeleteActionEvent(e);
			}
		});
		btnNewButton_2.setIcon(new ImageIcon(SchoolTypeManageInterFrm.class.getResource("/images/delete.png")));
		
		JButton btnNewButton_1 = new JButton("Modify");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schoolTypeUpdateActionEvent(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(SchoolTypeManageInterFrm.class.getResource("/images/modify.png")));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_1)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(44)
							.addComponent(lblNewLabel_2)
							.addGap(32)
							.addComponent(schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.LEADING, gl_panel.createSequentialGroup()
							.addComponent(lblSchoolDistrictDesc)
							.addGap(18)
							.addComponent(schoolTypeDescTxt, GroupLayout.PREFERRED_SIZE, 380, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(btnNewButton_1)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnNewButton_2)))
					.addContainerGap(22, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2)
						.addComponent(schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(37)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSchoolDistrictDesc)
						.addComponent(schoolTypeDescTxt, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_2)
						.addComponent(btnNewButton_1))
					.addContainerGap(19, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		schoolTypeTable = new JTable();
		schoolTypeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				schoolTypeTableMousePressed(e);
			}
		});
		schoolTypeTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"id", "School District Name", "School District Desc"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		schoolTypeTable.getColumnModel().getColumn(1).setPreferredWidth(143);
		schoolTypeTable.getColumnModel().getColumn(2).setPreferredWidth(310);
		scrollPane.setViewportView(schoolTypeTable);
		getContentPane().setLayout(groupLayout);
		
		this.fillTable(new SchoolType());

	}
	private void schoolTypeDeleteActionEvent(ActionEvent evt) {
		// TODO Auto-generated method stub
		String id=idTxt.getText();
		if(StringUtil.isEmpty(id)){
			JOptionPane.showMessageDialog(null, "Please choose the item you want to delete");
			return;
		}
		int n=JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the record.");
		if(n==0){
			Connection con=null;
			try{
				con=dbUtil.getCon();
				// ?????
				boolean flag=houseDao.existHouseBySchoolTypeId(con, id);
				if(flag){
					JOptionPane.showMessageDialog(null, "Are yo");
					return;
				}
				int deleteNum=schoolTypeDao.delete(con, id);
				if(deleteNum==1){
					JOptionPane.showMessageDialog(null, "delete succssfully");
					this.resetValue();
					this.fillTable(new SchoolType());
				}else{
					JOptionPane.showMessageDialog(null, "delete failed");
				}
			}catch(Exception e){
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "delete failed");
			}finally{
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	private void schoolTypeUpdateActionEvent(ActionEvent evt) {
		// TODO Auto-generated method stub
		String id=idTxt.getText();
		String schoolTypeName=schoolTypeNameTxt.getText();
		String schoolTypeDesc=schoolTypeDescTxt.getText();
		if(StringUtil.isEmpty(id)){
			JOptionPane.showMessageDialog(null, "Can not be empty");
			return;
		}
		if(StringUtil.isEmpty(schoolTypeName)){
			JOptionPane.showMessageDialog(null, "Can not be empty");
			return;
		}
		SchoolType schoolType=new SchoolType(Integer.parseInt(id),schoolTypeName,schoolTypeDesc);
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int modifyNum=schoolTypeDao.update(con, schoolType);
			if(modifyNum==1){
				JOptionPane.showMessageDialog(null, "Successflly");
				this.resetValue();
				this.fillTable(new SchoolType());
			}else{
				JOptionPane.showMessageDialog(null, "fail");
			}
		}catch(Exception e1){
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "fail");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
		
	}

	private void resetValue() {
		// TODO Auto-generated method stub
		this.idTxt.setText("");
		this.schoolTypeNameTxt.setText("");
		this.schoolTypeDescTxt.setText("");
		
	}

	private void schoolTypeTableMousePressed(MouseEvent evt) {
		// TODO Auto-generated method stub
		int row=schoolTypeTable.getSelectedRow();
		idTxt.setText((String)schoolTypeTable.getValueAt(row, 0));
		schoolTypeNameTxt.setText((String)schoolTypeTable.getValueAt(row, 1));
		schoolTypeDescTxt.setText((String)schoolTypeTable.getValueAt(row, 2));
	}

	private void schoolTypeSearchActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		String s_schoolTypeName=this. s_schoolTypeNameTxt.getText();
		SchoolType schoolType=new SchoolType();
		schoolType.setSchoolTypeName(s_schoolTypeName);
		this.fillTable(schoolType);
		 schoolTypeDescTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
		
	}

	private void fillTable(SchoolType schoolType){
		DefaultTableModel dtm=(DefaultTableModel) schoolTypeTable.getModel();
		dtm.setRowCount(0); 
		Connection con=null;
		try{
			con=dbUtil.getCon();
			ResultSet rs= schoolTypeDao.list(con, schoolType);
			while(rs.next()){
				Vector v=new Vector();
				v.add(rs.getString("id"));
				v.add(rs.getString("schoolTypeName"));
				v.add(rs.getString("schoolTypeDesc"));
				dtm.addRow(v);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
