package com.java1234.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;

import com.java1234.dao.RefuseTypeDao;
import com.java1234.model.RefuseType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class RefuseTypeAddInterFrm extends JInternalFrame {
	private JTextField refuseTypeNameTxt;
	private JTextArea refuseTypeDescTxt;
	
	private DbUtil dbUtil=new DbUtil();
	private RefuseTypeDao refuseTypeDao=new RefuseTypeDao();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RefuseTypeAddInterFrm frame = new RefuseTypeAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RefuseTypeAddInterFrm() {
		setTitle("RefuseType Add");
		setMaximizable(true);
		setIconifiable(true);
		setClosable(true);
		setBounds(100, 100, 775, 528);
		
		JLabel lblNewLabel = new JLabel("Refuse Type Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JLabel lblNewLabel_1 = new JLabel("Refuse District Desc:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		refuseTypeNameTxt = new JTextField();
		refuseTypeNameTxt.setColumns(10);
		
		refuseTypeDescTxt = new JTextArea();
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refuseTypeAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(RefuseTypeAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(RefuseTypeAddInterFrm.class.getResource("/images/reset.png")));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(145)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addComponent(lblNewLabel_1))
							.addGap(27)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(refuseTypeNameTxt)
								.addComponent(refuseTypeDescTxt, GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE))
							.addContainerGap(148, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED, 291, Short.MAX_VALUE)
							.addComponent(btnNewButton_1)
							.addGap(129))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(89)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(refuseTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(61)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(refuseTypeDescTxt, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addGap(61))
		);
		getContentPane().setLayout(groupLayout);
		
		refuseTypeDescTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));

	}

	private void refuseTypeAddActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		String refuseTypeName=this.refuseTypeNameTxt.getText();
		String refuseTypeDesc=this.refuseTypeDescTxt.getText();
		if(StringUtil.isEmpty(refuseTypeName)){
			JOptionPane.showMessageDialog(null, "can not be null");
			return;
		}
		RefuseType refuseType=new RefuseType(refuseTypeName,refuseTypeDesc);
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int n= refuseTypeDao.add(con, refuseType);
			if(n==1){
				JOptionPane.showMessageDialog(null, "Add Successfully");
				resetValue();
			}else{
				JOptionPane.showMessageDialog(null, "Failed Add");
			}
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failed");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void resetValueActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		this.resetValue();
	}

	private void resetValue() {
		// TODO Auto-generated method stub
		this.refuseTypeNameTxt.setText("");
		this.refuseTypeDescTxt.setText("");
	}

}
