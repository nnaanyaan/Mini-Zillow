package com.java1234.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;

import com.java1234.dao.SchoolTypeDao;
import com.java1234.model.SchoolType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

public class SchoolTypeAddInterFrm extends JInternalFrame {
	private JTextField schoolTypeNameTxt;
	private JTextArea schoolTypeDescTxt;
	private DbUtil dbUtil=new DbUtil();
	private SchoolTypeDao schoolTypeDao=new SchoolTypeDao();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SchoolTypeAddInterFrm frame = new SchoolTypeAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SchoolTypeAddInterFrm() {
		setClosable(true);
		setResizable(true);
		setMaximizable(true);
		setIconifiable(true);
		setTitle("School District Add");
		setBounds(100, 100, 779, 512);
		
		JLabel lblNewLabel = new JLabel("School District Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JLabel lblNewLabel_1 = new JLabel("School District Desc:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		schoolTypeNameTxt = new JTextField();
		schoolTypeNameTxt.setColumns(10);
		
		schoolTypeDescTxt = new JTextArea();
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schoolTypeAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(SchoolTypeAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(SchoolTypeAddInterFrm.class.getResource("/images/reset.png")));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(124)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnNewButton)
							.addGap(250)
							.addComponent(btnNewButton_1)
							.addGap(195))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addComponent(lblNewLabel_1))
							.addGap(27)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(schoolTypeDescTxt)
								.addComponent(schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, 249, GroupLayout.PREFERRED_SIZE))
							.addContainerGap(226, Short.MAX_VALUE))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(85)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(schoolTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(42)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1)
						.addComponent(schoolTypeDescTxt, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addGap(117))
		);
		getContentPane().setLayout(groupLayout);
		schoolTypeDescTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));

	}

	private void schoolTypeAddActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		String schoolTypeName=this.schoolTypeNameTxt.getText();
		String schoolTypeDesc=this.schoolTypeDescTxt.getText();
		if(StringUtil.isEmpty(schoolTypeName)){
			JOptionPane.showMessageDialog(null, "can not be null");
			return;
		}
		SchoolType schoolType=new SchoolType(schoolTypeName,schoolTypeDesc);
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int n= schoolTypeDao.add(con, schoolType);
			if(n==1){
				JOptionPane.showMessageDialog(null, "Add Successfully");
				resetValue();
			}else{
				JOptionPane.showMessageDialog(null, "Failed Add");
			}
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failed");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void resetValueActionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		this.resetValue();
		
	}

	private void resetValue() {
		// TODO Auto-generated method stub
		this.schoolTypeNameTxt.setText("");
		this.schoolTypeDescTxt.setText("");
	}
}
