package com.java1234.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JDesktopPane;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	private JDesktopPane table = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrm() {
		setTitle("House Management Main UI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 530);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Basic Data Maintainance");
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_1 = new JMenu("School District Management");
		mnNewMenu_1.setIcon(new ImageIcon(MainFrm.class.getResource("/images/school.png")));
		mnNewMenu.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("School Distrct Add");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SchoolTypeAddInterFrm schoolTypeAddInterFrm=new SchoolTypeAddInterFrm();
				schoolTypeAddInterFrm.setVisible(true);
				table.add(schoolTypeAddInterFrm);
			}
		});
		mntmNewMenuItem.setIcon(new ImageIcon(MainFrm.class.getResource("/images/add.png")));
		mnNewMenu_1.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("School District Maintainace");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SchoolTypeManageInterFrm schoolTypeManageInterFrm=new SchoolTypeManageInterFrm();
				schoolTypeManageInterFrm.setVisible(true);
				table.add(schoolTypeManageInterFrm);
			}
		});
		mntmNewMenuItem_1.setIcon(new ImageIcon(MainFrm.class.getResource("/images/edit.png")));
		mnNewMenu_1.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_2 = new JMenu("Refuse District Management");
		mnNewMenu_2.setIcon(new ImageIcon(MainFrm.class.getResource("/images/refuse.png")));
		mnNewMenu.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Refuse District Add");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RefuseTypeAddInterFrm refuseTypeAddInterFrm=new RefuseTypeAddInterFrm();
				refuseTypeAddInterFrm.setVisible(true);
				table.add(refuseTypeAddInterFrm);
			}
		});
		mntmNewMenuItem_2.setIcon(new ImageIcon(MainFrm.class.getResource("/images/add.png")));
		mnNewMenu_2.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Refuse District Maintainace");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RefuseTypeManageInterFrm refuseTypeManageInterFrm=new RefuseTypeManageInterFrm();
				refuseTypeManageInterFrm.setVisible(true);
				table.add(refuseTypeManageInterFrm);
			}
		});
		mntmNewMenuItem_3.setIcon(new ImageIcon(MainFrm.class.getResource("/images/edit.png")));
		mnNewMenu_2.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_3 = new JMenu("House Management");
		mnNewMenu_3.setIcon(new ImageIcon(MainFrm.class.getResource("/images/room.png")));
		mnNewMenu.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("House Add");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HouseAddInterFrm houseAddInterFrm=new HouseAddInterFrm();
				houseAddInterFrm.setVisible(true);
				table.add(houseAddInterFrm);
			}
		});
		mntmNewMenuItem_4.setIcon(new ImageIcon(MainFrm.class.getResource("/images/add.png")));
		mnNewMenu_3.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("House Maintainance");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HouseManageInterFrm houseManageInterFrm=new HouseManageInterFrm();
				houseManageInterFrm.setVisible(true);
				table.add(houseManageInterFrm);
			}
		});
		mntmNewMenuItem_5.setIcon(new ImageIcon(MainFrm.class.getResource("/images/edit.png")));
		mnNewMenu_3.add(mntmNewMenuItem_5);
		
		JMenuItem mntmSafeExit = new JMenuItem("Safe Exit");
		mntmSafeExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result=JOptionPane.showConfirmDialog(null, "Do you want to quit now?");
				//System.out.println(result);
				if(result==0){
					dispose();
				}
			}
		});
		mntmSafeExit.setIcon(new ImageIcon(MainFrm.class.getResource("/images/exit.png")));
		mnNewMenu.add(mntmSafeExit);
		
		JMenu mnAboutUs = new JMenu("About Us");
		menuBar.add(mnAboutUs);
		
		JMenuItem mntmAboutOurTeam = new JMenuItem("About Our Team");
		mntmAboutOurTeam.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Java1234InterFrm java1234InterFrm=new Java1234InterFrm();
				java1234InterFrm.setVisible(true);
				table.add(java1234InterFrm);
			}
		});
		mntmAboutOurTeam.setIcon(new ImageIcon(MainFrm.class.getResource("/images/about.png")));
		mnAboutUs.add(mntmAboutOurTeam);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		table = new JDesktopPane();
		table.setBackground(Color.PINK);
		contentPane.add(table, BorderLayout.CENTER);
		
		// to make the frame full of the screen.
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}

}
