package com.java1234.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.java1234.dao.HouseDao;
import com.java1234.dao.SchoolTypeDao;
import com.java1234.model.House;
import com.java1234.model.SchoolType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class HouseAddInterFrm extends JFrame {

	private JPanel contentPane;
	private JTextField addressTxt;
	private JTextField properclassTxt;
	private JTextField priceTxt;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField refuseTxt;
	
	private JComboBox schoolTypeJcb;
	private JRadioButton rentJrb;
	private JRadioButton sellJrb;
	
	private DbUtil dbUtil=new DbUtil();
	private SchoolTypeDao schoolTypeDao=new SchoolTypeDao();
	private HouseDao houseDao=new HouseDao();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HouseAddInterFrm frame = new HouseAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HouseAddInterFrm() {
		setTitle("House Add");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 649);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("address:");
		
		addressTxt = new JTextField();
		addressTxt.setColumns(10);
		
		JLabel lblPropertyclass = new JLabel("propertyclass:");
		
		properclassTxt = new JTextField();
		properclassTxt.setColumns(10);
		
		JLabel lblPropertyUse = new JLabel("property use:");
		
		JLabel lblNewLabel_1 = new JLabel("house price:");
		
		priceTxt = new JTextField();
		priceTxt.setColumns(10);
		
		rentJrb = new JRadioButton("Rent");
		buttonGroup.add(rentJrb);
		rentJrb.setSelected(true);
		
		sellJrb = new JRadioButton("Sell");
		buttonGroup.add(sellJrb);
		
		JLabel lblSchoolDistrictDesc = new JLabel("Refuse District Id:");
		
		JLabel lblSchoolDistrictName = new JLabel("School District Name:");
		
		refuseTxt = new JTextField();
		refuseTxt.setColumns(10);
		
		schoolTypeJcb = new JComboBox();
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				houseAddActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(HouseAddInterFrm.class.getResource("/images/add.png")));
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformed(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(HouseAddInterFrm.class.getResource("/images/reset.png")));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(lblNewLabel)
											.addGap(18)
											.addComponent(addressTxt, GroupLayout.PREFERRED_SIZE, 244, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(lblPropertyUse)
											.addGap(33)
											.addComponent(rentJrb)
											.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(sellJrb)))
									.addGap(49)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblPropertyclass)
										.addComponent(lblNewLabel_1))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(priceTxt)
										.addComponent(properclassTxt, GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblSchoolDistrictName)
										.addComponent(lblSchoolDistrictDesc))
									.addGap(18)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(refuseTxt)
										.addComponent(schoolTypeJcb, 0, 134, Short.MAX_VALUE))))
							.addContainerGap(44, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED, 394, Short.MAX_VALUE)
							.addComponent(btnNewButton_1)
							.addGap(54))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(52)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(addressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPropertyclass)
						.addComponent(properclassTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(64)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(priceTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(sellJrb)
						.addComponent(rentJrb)
						.addComponent(lblPropertyUse))
					.addGap(70)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblSchoolDistrictName)
						.addComponent(schoolTypeJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(74)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSchoolDistrictDesc)
						.addComponent(refuseTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 141, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addGap(75))
		);
		contentPane.setLayout(gl_contentPane);
		
		fillSchoolType();
	}
	private void resetValueActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		this.resetValue();
		
	}

	private void houseAddActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		String address=this.addressTxt.getText();
		String properclass=this.properclassTxt.getText();
		String price=this.priceTxt.getText();
		String refuse=this.refuseTxt.getText();
		
		if(StringUtil.isEmpty(address)){
			JOptionPane.showMessageDialog(null, "address can not be null.");
			return;
		}
		
		if(StringUtil.isEmpty(properclass)){
			JOptionPane.showMessageDialog(null, "properclass can not be null.");
			return;
		}
		
		if(StringUtil.isEmpty(price)){
			JOptionPane.showMessageDialog(null, "price can not be null.");
			return;
		}
		
		String properuse="";
		if(sellJrb.isSelected()){
			properuse="sell";
		}else if(rentJrb.isSelected()){
			properuse="rent";
		}
		
		SchoolType schoolType=(SchoolType) schoolTypeJcb.getSelectedItem();
		int schoolTypeId=schoolType.getId();
		
		House house=new House(address,properclass, properuse, Integer.parseInt(price) , schoolTypeId,  Integer.parseInt(refuse));
		
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int addNum=houseDao.add(con, house);
			if(addNum==1){
				JOptionPane.showMessageDialog(null, "successfully add.");
				resetValue();
			}else{
				JOptionPane.showMessageDialog(null, "failed");
			}
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failed");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	private void resetValue() {
		// TODO Auto-generated method stub
		this.addressTxt.setText("");
		this.properclassTxt.setText("");
		this.priceTxt.setText("");
		this.sellJrb.setSelected(true);
		this.refuseTxt.setText("");
		if(this.schoolTypeJcb.getItemCount()>0){
			this.schoolTypeJcb.setSelectedIndex(0);
		}
		
	}

	// this is for the down frame.
	private void fillSchoolType(){
		Connection con=null;
		SchoolType schoolType=null;
		try{
			con=dbUtil.getCon();
			ResultSet rs=schoolTypeDao.list(con, new SchoolType());
			while(rs.next()){
				schoolType=new SchoolType();
				schoolType.setId(rs.getInt("id"));
				schoolType.setSchoolTypeName(rs.getString("schoolTypeName"));
				this.schoolTypeJcb.addItem(schoolType);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			
		}
	}
}
