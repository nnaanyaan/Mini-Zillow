package com.java1234.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.HouseDao;
import com.java1234.dao.SchoolTypeDao;
import com.java1234.model.House;
import com.java1234.model.SchoolType;
import com.java1234.util.DbUtil;

import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class HouseManageInterFrm extends JFrame {

	private JPanel contentPane;
	private JTable housetable;
	private JTextField s_addressTxt;
	private JTextField s_properclassTxt;
	
	private DbUtil dbUtil=new DbUtil();
	
	private SchoolTypeDao schoolTypeDao=new SchoolTypeDao();
	private HouseDao houseDao=new HouseDao();
	
	private JComboBox s_schooldistrictJcb;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HouseManageInterFrm frame = new HouseManageInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HouseManageInterFrm() {
		setTitle("House Management");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 753, 429);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Search Condition", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(scrollPane, Alignment.LEADING)
						.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 709, Short.MAX_VALUE))
					.addContainerGap(85, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(325, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel = new JLabel("address\uFF1A");
		
		s_addressTxt = new JTextField();
		s_addressTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("properclass\uFF1A");
		
		s_properclassTxt = new JTextField();
		s_properclassTxt.setColumns(10);
		
		JLabel lblSchooldistrict = new JLabel("schooldistrict\uFF1A");
		
		s_schooldistrictJcb = new JComboBox();
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				houseSearchActionPerformed(e);
			}
		});
		btnNewButton.setIcon(new ImageIcon(HouseManageInterFrm.class.getResource("/images/search.png")));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(s_addressTxt, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(s_properclassTxt, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblSchooldistrict)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(s_schooldistrictJcb, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton)
					.addContainerGap(106, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(s_addressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1)
						.addComponent(s_properclassTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblSchooldistrict)
						.addComponent(s_schooldistrictJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addContainerGap(38, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		housetable = new JTable();
		scrollPane.setViewportView(housetable);
		housetable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "address", "propertyclass", "property use", "price", "schoolId", "refuseId"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, true, false, true, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		housetable.getColumnModel().getColumn(1).setPreferredWidth(219);
		housetable.getColumnModel().getColumn(2).setPreferredWidth(105);
		housetable.getColumnModel().getColumn(3).setPreferredWidth(95);
		housetable.getColumnModel().getColumn(4).setPreferredWidth(93);
		housetable.getColumnModel().getColumn(5).setPreferredWidth(91);
		housetable.getColumnModel().getColumn(6).setPreferredWidth(99);
		contentPane.setLayout(gl_contentPane);
		
		this.fillSchoolType("search");
		this.fillSchoolType("modify");
		this.fillTable(new House());
	}
	
	private void houseSearchActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		String address=this.s_addressTxt.getText();
		String properclass=this.s_properclassTxt.getText();
		SchoolType schoolType=(SchoolType) this.s_schooldistrictJcb.getSelectedItem();
		int schoolTypeId=schoolType.getId();
		
		House house=new House(address,properclass,schoolTypeId);
		this.fillTable(house);
		
	}

	private void fillTable(House house) {
		// TODO Auto-generated method stub
		DefaultTableModel dtm=(DefaultTableModel) housetable.getModel();
		dtm.setRowCount(0); 
		Connection con=null;
		try{
			con=dbUtil.getCon();
			ResultSet rs=houseDao.list(con, house);
			while(rs.next()){
				Vector v=new Vector();
				v.add(rs.getString("id"));
				v.add(rs.getString("address"));
				v.add(rs.getString("propertyclass"));
				v.add(rs.getString("propertyuse"));
				v.add(rs.getInt("price"));
				v.add(rs.getString("schoolTypeId"));
				v.add(rs.getString("refuseTypeId"));
				dtm.addRow(v);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	private void fillSchoolType(String type){
		Connection con=null;
		SchoolType schoolType=null;
		try{
			con=dbUtil.getCon();
			ResultSet rs=schoolTypeDao.list(con, new SchoolType());
			if("search".equals(type)){
				schoolType=new SchoolType();
				schoolType.setSchoolTypeName("Please choose:");
				schoolType.setId(-1);
				this.s_schooldistrictJcb.addItem(schoolType);
			}
			while(rs.next()){
				schoolType=new SchoolType();
				schoolType.setSchoolTypeName(rs.getString("schoolTypeName"));
				schoolType.setId(rs.getInt("id"));
				if("search".equals(type)){
					this.s_schooldistrictJcb.addItem(schoolType);
				}else if("modify".equals(type)){
					this.s_schooldistrictJcb.addItem(schoolType);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
