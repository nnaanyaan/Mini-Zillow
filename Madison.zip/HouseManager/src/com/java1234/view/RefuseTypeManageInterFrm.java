package com.java1234.view;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.java1234.dao.HouseDao;
import com.java1234.dao.RefuseTypeDao;
import com.java1234.model.House;
import com.java1234.model.RefuseType;
import com.java1234.util.DbUtil;
import com.java1234.util.StringUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RefuseTypeManageInterFrm extends JInternalFrame {
	
	private JTable refuseTypeTable;
	private DbUtil dbUtil=new DbUtil();
	private RefuseTypeDao refuseTypeDao=new RefuseTypeDao();
	
	private HouseDao houseDao=new HouseDao();
	private JTextField s_refuseTypeNameTxt;
	private JTextField idTxt;
	private JTextField refuseTypeNameTxt;
	private JTextArea refuseTypeDescTxt;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RefuseTypeManageInterFrm frame = new RefuseTypeManageInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RefuseTypeManageInterFrm() {
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setTitle("Refuse District Management");
		setBounds(100, 100, 778, 647);
		
		JScrollPane scrollPane = new JScrollPane();
//		scrollPane.addMouseListener(new MouseAdapter() {
//			@Override
//			public void mousePressed(MouseEvent e) {
//				refuseTypeTableMousePressed(e);
//			}
//		});
		
		JLabel lblRefuseDistrictName = new JLabel("Refuse District Name:");
		lblRefuseDistrictName.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		s_refuseTypeNameTxt = new JTextField();
		s_refuseTypeNameTxt.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refuseTypeSearchActionPerformed(e);
			}
		});
		btnSearch.setIcon(new ImageIcon(RefuseTypeManageInterFrm.class.getResource("/images/search.png")));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Delete and Modify", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(85)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 549, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblRefuseDistrictName)
								.addGap(26)
								.addComponent(s_refuseTypeNameTxt, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnSearch))
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 548, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(128, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(40)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblRefuseDistrictName)
						.addComponent(s_refuseTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSearch))
					.addGap(60)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 149, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 252, GroupLayout.PREFERRED_SIZE)
					.addGap(38))
		);
		
		JLabel lblNewLabel = new JLabel("id:");
		
		idTxt = new JTextField();
		idTxt.setEditable(false);
		idTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Refuse District Name:");
		
		refuseTypeNameTxt = new JTextField();
		refuseTypeNameTxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Refuse District Collection Url:");
		
		refuseTypeDescTxt = new JTextArea();
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refuseTypeDeleteActionEvent(e);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(RefuseTypeManageInterFrm.class.getResource("/images/delete.png")));
		
		JButton btnModify = new JButton("Modify");
		btnModify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refuseTypeUpdateActionEvent(e);
			}
		});
		btnModify.setIcon(new ImageIcon(RefuseTypeManageInterFrm.class.getResource("/images/modify.png")));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
									.addGap(34)
									.addComponent(lblNewLabel_1)
									.addGap(18)
									.addComponent(refuseTypeNameTxt, GroupLayout.PREFERRED_SIZE, 175, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel_2)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(refuseTypeDescTxt, GroupLayout.PREFERRED_SIZE, 302, GroupLayout.PREFERRED_SIZE))))
						.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
							.addGap(21)
							.addComponent(btnModify)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(btnNewButton_1)))
					.addContainerGap(45, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
							.addComponent(idTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(lblNewLabel_1)
							.addComponent(refuseTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblNewLabel))
					.addGap(31)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(refuseTypeDescTxt, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnModify))
					.addContainerGap(23, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		refuseTypeTable = new JTable();
		refuseTypeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				refuseTypeTableMousePressed(e);
			}
		});
		refuseTypeTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Refuse District Name", "Refuse District Collection Url"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		refuseTypeTable.getColumnModel().getColumn(0).setPreferredWidth(69);
		refuseTypeTable.getColumnModel().getColumn(1).setPreferredWidth(131);
		refuseTypeTable.getColumnModel().getColumn(2).setPreferredWidth(237);
		scrollPane.setViewportView(refuseTypeTable);
		getContentPane().setLayout(groupLayout);
		this.fillTable(new RefuseType());

	   refuseTypeDescTxt.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));

	}

	private void refuseTypeDeleteActionEvent(ActionEvent evt) {
		// TODO Auto-generated method stub
		String id=idTxt.getText();
		if(StringUtil.isEmpty(id)){
			JOptionPane.showMessageDialog(null, "Please choose the item you want to delete");
			return;
		}
		int n=JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the record.");
		if(n==0){
			Connection con=null;
			try{
				con=dbUtil.getCon();
				// ????
				boolean flag=houseDao.existHouseBySchoolTypeId(con, id);
				if(flag){
					JOptionPane.showMessageDialog(null, "Are yo");
					return;
				}
				int deleteNum=refuseTypeDao.delete(con, id);
				if(deleteNum==1){
					JOptionPane.showMessageDialog(null, "delete succssfully");
					this.resetValue();
					this.fillTable(new RefuseType());
				}else{
					JOptionPane.showMessageDialog(null, "delete failed");
				}
			}catch(Exception e){
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "delete failed");
			}finally{
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	private void refuseTypeUpdateActionEvent(ActionEvent e) {
		// TODO Auto-generated method stub
		String id=idTxt.getText();
		String refuseTypeName=refuseTypeNameTxt.getText();
		String refuseTypeDesc=refuseTypeDescTxt.getText();
		if(StringUtil.isEmpty(id)){
			JOptionPane.showMessageDialog(null, "Can not be empty");
			return;
		}
		if(StringUtil.isEmpty(refuseTypeName)){
			JOptionPane.showMessageDialog(null, "Can not be empty");
			return;
		}
		RefuseType refuseType=new RefuseType(Integer.parseInt(id),refuseTypeName,refuseTypeDesc);
		Connection con=null;
		try{
			con=dbUtil.getCon();
			int modifyNum=refuseTypeDao.update(con, refuseType);
			if(modifyNum==1){
				JOptionPane.showMessageDialog(null, "Successflly");
				this.resetValue();
				this.fillTable(new RefuseType());
			}else{
				JOptionPane.showMessageDialog(null, "fail");
			}
		}catch(Exception e1){
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "fail");
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		}
		
	}

	private void resetValue() {
		// TODO Auto-generated method stub
		this.idTxt.setText("");
		this.refuseTypeNameTxt.setText("");
		this.refuseTypeDescTxt.setText("");
		
	}

	private void refuseTypeTableMousePressed(MouseEvent evt) {
		// TODO Auto-generated method stub
		int row=refuseTypeTable.getSelectedRow();
		idTxt.setText((String)refuseTypeTable.getValueAt(row, 0));
		refuseTypeNameTxt.setText((String)refuseTypeTable.getValueAt(row, 1));
		refuseTypeDescTxt.setText((String)refuseTypeTable.getValueAt(row, 2));
	}

	private void refuseTypeSearchActionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		
		String s_refuseTypeName=this. s_refuseTypeNameTxt.getText();
		RefuseType refuseType=new RefuseType();
		refuseType.setRefuseTypeName(s_refuseTypeName);
		this.fillTable(refuseType);
		
	}

	private void fillTable(RefuseType refuseType){
		DefaultTableModel dtm=(DefaultTableModel) refuseTypeTable.getModel();
		dtm.setRowCount(0); 
		Connection con=null;
		try{
			con=dbUtil.getCon();
			ResultSet rs= refuseTypeDao.list(con, refuseType);
			while(rs.next()){
				Vector v=new Vector();
				v.add(rs.getString("id"));
				v.add(rs.getString("refuseTypeName"));
				v.add(rs.getString("refuseTypeDesc"));
				dtm.addRow(v);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
